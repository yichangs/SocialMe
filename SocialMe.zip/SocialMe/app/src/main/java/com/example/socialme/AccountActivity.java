package com.example.socialme;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.socialme.Matches.ChatFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class AccountActivity extends AppCompatActivity {
    private BottomNavigationView  bottomNav;

   // private CircleImageView profileImageView;

   // FirebaseAuth mAuth;
   // private DatabaseReference databaseReference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account);

       // mAuth = FirebaseAuth.getInstance();
        // databaseReference = FirebaseDatabase.getInstance().getReference();
        // profileImageView = findViewById(R.id.profilePic);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);

        bottomNav = findViewById(R.id.bottom_navigation);
        ProfileFragment f = new ProfileFragment();
//        Bundle args = new Bundle();
//        args.putString("petBreed", getIntent().getExtras().getString("petBreed"));
//        f.setArguments(args);
        getSupportFragmentManager().beginTransaction().replace(R.id.body_container, f).commit();
        bottomNav.setSelectedItemId(R.id.nav_profile);

        bottomNav.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Fragment fragment = null;
                switch (item.getItemId()) {
                    case R.id.nav_profile:
//                        fragment = new ProfileFragment();
//                        Bundle args = new Bundle();
//                        args.putString("name", getIntent().getExtras().getString("name"));
//                        System.out.println("the name is " + getIntent().getExtras().getString("name"));
//                        fragment.setArguments(args);
//                         String test = getIntent().getExtras().getString("petBreed");
                         fragment = new ProfileFragment();
                        break;

                    case R.id.nav_chat:
                        fragment = new ChatFragment();
                        break;

                    case R.id.nav_discover:
                        fragment = new DiscoverFragment();
                        break;
                }





                getSupportFragmentManager().beginTransaction().replace(R.id.body_container, fragment).commit();

                return true;
            }
        });

       // getUserinfo();
    }

//    private void getUserinfo() {
//        databaseReference.child(mAuth.getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists() && snapshot.getChildrenCount() > 0)
//                {
//                    if (snapshot.hasChild("image"))
//                    {
//                        String image = snapshot.child("image").getValue().toString();
//                        Picasso.get().load(image).into(profileImageView);
//
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }

}
