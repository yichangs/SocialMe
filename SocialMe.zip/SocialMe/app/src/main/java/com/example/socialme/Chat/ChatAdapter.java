package com.example.socialme.Chat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.socialme.R;

import java.util.List;

//public class ChatAdapter extends RecyclerView.Adapter<ChatViewHolders> {
//    private List<ChatObject> chatList;
//    private Context context;
//
//
//    public ChatAdapter(List<ChatObject> matchesList, Context context) {
//        this.chatList = matchesList;
//        this.context = context;
//
//    }
//    @NonNull
//    @Override
//    public ChatViewHolders onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat, null, false);
//        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        layoutView.setLayoutParams(lp);
//        ChatViewHolders rcv = new ChatViewHolders((layoutView));
//
//        return rcv;
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull ChatViewHolders holder, int position) {
//        holder.mMessage.setText(chatList.get(position).getMessage());
//        if (chatList.get(position).getCurrentUser()) {
//            holder.mMessage.setGravity(Gravity.END);
//            holder.mMessage.setTextColor(Color.parseColor("#404040"));
//            holder.mContainer.setBackgroundColor(Color.parseColor("#F4F4F4"));
//        } else {
//            holder.mMessage.setGravity(Gravity.START);
//            holder.mMessage.setTextColor(Color.parseColor("#FFFFFF"));
//            holder.mContainer.setBackgroundColor(Color.parseColor("#2DB4C8"));
//        }
//    }
//
//    @Override
//    public int getItemCount() {
//        return chatList.size();
//    }
//}


public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.MyViewHolder> {


    private List<ChatObject> chatList;
    private final Context context;
    private String userId;

    public ChatAdapter(List<ChatObject> chatList, Context context) {
        this.chatList = chatList;
        this.context = context;
    }

    @NonNull
    @Override
    public ChatAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_chat, null));
    }

    @Override
    public void onBindViewHolder(@NonNull ChatAdapter.MyViewHolder holder, int position) {
        ChatObject obj = chatList.get(position);

//        if (obj.getUserId().equals(userId)) {
//            holder.myLayout.setVisibility(View.VISIBLE);
//            holder.oppoLayout.setVisibility(View.GONE);
//
//            holder.myMessage.setText(obj.getMessage());
//            holder.myTime.setText(obj.getDate()+" "+obj.getTime());
//        } else {
//            holder.oppoLayout.setVisibility(View.VISIBLE);
//            holder.myLayout.setVisibility(View.GONE);
//
//            holder.oppoMessage.setText(obj.getMessage());
//            holder.oppoTime.setText(obj.getDate()+" "+obj.getTime());
//        }


        if (obj.getCurrentUser()) {
            holder.myLayout.setVisibility(View.VISIBLE);
            holder.oppoLayout.setVisibility(View.GONE);

            holder.myMessage.setText(obj.getMessage());
            holder.myTime.setText(obj.getDate()+" "+obj.getTime());
        } else {
            holder.oppoLayout.setVisibility(View.VISIBLE);
            holder.myLayout.setVisibility(View.GONE);

            holder.oppoMessage.setText(obj.getMessage());
            holder.oppoTime.setText(obj.getDate()+" "+obj.getTime());
        }


    }

    @Override
    public int getItemCount() {
        return chatList.size();
    }

    public void updateChatList(List<ChatObject> chatList) {
        this.chatList = chatList;
    }

    static class MyViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout oppoLayout, myLayout;
        private TextView oppoMessage, myMessage;
        private TextView oppoTime, myTime;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            oppoLayout = itemView.findViewById(R.id.oppoLayout);
            myLayout = itemView.findViewById(R.id.myLayout);
            oppoMessage = itemView.findViewById(R.id.oppoMessage);
            myMessage = itemView.findViewById(R.id.myMessage);
            oppoTime = itemView.findViewById(R.id.oppoMsgTime);
            myTime = itemView.findViewById(R.id.myMsgTime);

        }
    }
}