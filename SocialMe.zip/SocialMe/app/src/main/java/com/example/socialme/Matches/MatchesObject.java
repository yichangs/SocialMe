package com.example.socialme.Matches;

//public class MatchesObject {
//    private String userId;
//    private String name;
//    private String profileImageUrl;
//    public MatchesObject (String userId, String name, String profileImageUrl) {
//        this.userId = userId;
//        this.name = name;
//        this.profileImageUrl = profileImageUrl;
//    }
//
//    public String getUserId() {
//        return userId;
//    }
//    public void setUserId(String userId) {
//        this.userId = userId;
//    }
//
//    public String getName() {
//        return name;
//    }
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    public String getProfileImageUrl() {
//        return profileImageUrl;
//    }
//    public void setProfileImageUrl(String profileImageUrl) {
//        this.profileImageUrl = profileImageUrl;
//    }
//}


public class MatchesObject {
    private String userId;
    private String name;
    private String profileImageUrl;
    private String lastMessage, chatKey;
    private int unseenMessages;

    public MatchesObject (String userId, String name, String profileImageUrl, String lastMessage, int unseenMessages, String chatKey) {
        this.userId = userId;
        this.name = name;
        this.profileImageUrl = profileImageUrl;
        this.lastMessage = lastMessage;
        this.unseenMessages = unseenMessages;
        this.chatKey = chatKey;
    }

    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getProfileImageUrl() {
        return profileImageUrl;
    }
//    public void setProfileImageUrl(String profileImageUrl) {
//        this.profileImageUrl = profileImageUrl;
//    }

    public String getLastMessage() {
        return lastMessage;
    }
//   public void setLastMessage(String lastMessage) {
//        this.lastMessage = lastMessage;
//    }

    public int getUnseenMessages() {
        return unseenMessages;
    }
//    public void setUnseenMessages(int unseenMessages) {
//        this.unseenMessages = unseenMessages;
//    }

    public String getChatKey() {
        return chatKey;
    }



}
