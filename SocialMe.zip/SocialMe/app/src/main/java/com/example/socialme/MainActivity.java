package com.example.socialme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
    private Button signButton;
    private Button createButton;
    private Button logInButton;
    private EditText email;
    private EditText password;
    private ImageView goBack;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        signButton = findViewById(R.id.signin);
        createButton = findViewById(R.id.create);
        logInButton = findViewById(R.id.signInButton);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        goBack = findViewById(R.id.goBack);
        mAuth = FirebaseAuth.getInstance();

        signButton.setOnClickListener((View v) -> {
            createButton.setVisibility(View.INVISIBLE);
            signButton.setVisibility(View.INVISIBLE);
            email.setVisibility(View.VISIBLE);
            password.setVisibility(View.VISIBLE);
            logInButton.setVisibility(View.VISIBLE);
            goBack.setVisibility(View.VISIBLE);
        });

        createButton.setOnClickListener((View v) -> {
            switchActivities();
        });

        logInButton.setOnClickListener((View v) -> {
            String editEmail = email.getText().toString().trim();
            String editPassword = password.getText().toString();

            if (editEmail.isEmpty()) {
                email.setError("Email is required!");
                email.requestFocus();
                return;
            }

            if (editPassword.isEmpty()) {
                password.setError("Password is required!");
                password.requestFocus();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(editEmail).matches()) {
                email.setError("Please provide valid email!");
                email.requestFocus();
                return;
            }

            mAuth.signInWithEmailAndPassword(editEmail, editPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {
                        startActivity(new Intent(MainActivity.this, AccountActivity.class));
                    } else {
                        Toast.makeText(MainActivity.this,"Failed to login! Please check your credentials", Toast.LENGTH_LONG).show();
                    }
                }
            });
        });

        goBack.setOnClickListener((View v) -> {
            createButton.setVisibility(View.VISIBLE);
            signButton.setVisibility(View.VISIBLE);
            email.setVisibility(View.INVISIBLE);
            password.setVisibility(View.INVISIBLE);
            logInButton.setVisibility(View.INVISIBLE);
            goBack.setVisibility(View.INVISIBLE);
        });
    }
    private void switchActivities() {
        Intent switchActivityIntent = new Intent(this, RegistrationActivity.class);
        startActivity(switchActivityIntent);
    }
}