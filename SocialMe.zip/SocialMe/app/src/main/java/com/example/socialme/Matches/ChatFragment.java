package com.example.socialme.Matches;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.socialme.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

//public class ChatFragment extends Fragment {
//    private RecyclerView mRecyclerView;
//    private RecyclerView.Adapter mMatchesAdapter;
//    private RecyclerView.LayoutManager mMatchesLayoutManager;
//    private String currentUserID;
//
//    @Override
//    public void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//       // currentUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
//    }
//
//
//
//    @Override
//    public View onCreateView(LayoutInflater inflater, ViewGroup container,
//                             Bundle savedInstanceState) {
//        // Inflate the layout for this fragment
//        return inflater.inflate(R.layout.fragment_chat, container, false);
//    }
//
//
//    @Override
//    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
//        super.onViewCreated(view, savedInstanceState);
//
//        currentUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
//
//        mRecyclerView = view.findViewById(R.id.recyclerView);
//        mRecyclerView.setNestedScrollingEnabled(false);
//        mRecyclerView.setHasFixedSize(true);
//        mMatchesLayoutManager = new LinearLayoutManager(getContext());
//        mRecyclerView.setLayoutManager(mMatchesLayoutManager);
//        mMatchesAdapter = new MatchesAdapter(getDataSetMatches(), getContext());
//        mRecyclerView.setAdapter(mMatchesAdapter);
//
//
//        getUserMatchId();
//
//    }
//
//    private void getUserMatchId() {
//
//        DatabaseReference matchDb = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID).child("connections").child("matches");
//        matchDb.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    for (DataSnapshot match : snapshot.getChildren()) {
//                        FetchMatchInformation(match.getKey());
//                    }
//                }
//            }
//
//            private void FetchMatchInformation(String key) {
//                DatabaseReference userDb = FirebaseDatabase.getInstance().getReference().child("Users").child(key);
//                userDb.addListenerForSingleValueEvent(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//                        if (snapshot.exists()) {
//                            String userId = snapshot.getKey();
//                            String name = "";
//                            String profileImageUrl = "";
//                            if (snapshot.child("name").getValue() != null) {
//                                name = snapshot.child("name").getValue().toString();
//                            }
//                            if (snapshot.child("profileImageUrl").getValue() != null) {
//                                profileImageUrl = snapshot.child("profileImageUrl").getValue().toString();
//                            }
//
//                            MatchesObject obj = new MatchesObject(userId, name, profileImageUrl);
//                            resultsMatches.add(obj);
//                            mMatchesAdapter.notifyDataSetChanged();
//                        }
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//
//    }
//
//    private ArrayList<MatchesObject> resultsMatches = new ArrayList<MatchesObject>();
//    private List<MatchesObject> getDataSetMatches() {
//        return resultsMatches;
//    }
//
//}

public class ChatFragment extends Fragment {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mMatchesAdapter;
    private RecyclerView.LayoutManager mMatchesLayoutManager;
    private String currentUserID;
    private CircleImageView userProfilePic;

    private int unseenMessages = 0;
    private String lastMessage = "";
    private String chatKey = "";

    private boolean dataSet = false;
    private String lastSeenMessage = "0";


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_chat, container, false);
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        userProfilePic = view.findViewById(R.id.userProfilePic);

        currentUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();

        mRecyclerView = view.findViewById(R.id.messageRecyclerView);
        mRecyclerView.setNestedScrollingEnabled(false);
        mRecyclerView.setHasFixedSize(true);
        mMatchesLayoutManager = new LinearLayoutManager(getContext());
        mRecyclerView.setLayoutManager(mMatchesLayoutManager);
        mMatchesAdapter = new MatchesAdapter(getDataSetMatches(), getContext());
        mRecyclerView.setAdapter(mMatchesAdapter);


        getUserMatchId();

    }

    private void getUserMatchId() {

        DatabaseReference matchDb = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID).child("connections").child("matches");
        DatabaseReference userDb = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID);
        userDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                final String profileImageUrl = snapshot.child("profileImageUrl").getValue(String.class);
                if (!profileImageUrl.isEmpty() && !profileImageUrl.equals("default")) {
                    Picasso.get().load(profileImageUrl).into(userProfilePic);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
        matchDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    resultsMatches.clear();

                    for (DataSnapshot match : snapshot.getChildren()) {
                        dataSet = false;
                        unseenMessages = 0;
                        lastMessage = "";
                        chatKey = "";
                        FetchMatchInformation(match.getKey());
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

//    private void getChatKey(String key) {
//        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID).child("connections").child("matches").child(key);
//        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                chatKey = snapshot.child("chatId").getValue(String.class);
//                lastSeenMessage = snapshot.child("last_msg").getValue(String.class);
//                System.out.println("The lastseenmessage is " + lastSeenMessage);
//                System.out.println("The chat key is " + chatKey);
//                FetchMatchInformation(key);
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }

//
//    private void FetchMatchInformation(String key) {
//        DatabaseReference userDb = FirebaseDatabase.getInstance().getReference();
//        userDb.child("Users").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    String userId = snapshot.getKey();
//                    String name = "";
//                    String profileImageUrl = "";
//
//                    if (snapshot.child("name").getValue() != null) {
//                        name = snapshot.child("name").getValue().toString();
//                    }
//                    if (snapshot.child("profileImageUrl").getValue() != null) {
//                        profileImageUrl = snapshot.child("profileImageUrl").getValue().toString();
//                    }
//                    //if (!dataSet) {
//                    if (true){
//                        dataSet = true;
//                        //lastMessage = lastMessage == null ? "" : lastMessage;
//                        System.out.println("***********");
//                        System.out.println("The last message is " + lastMessage + " the unseenmessages is " + unseenMessages);
//                        MatchesObject obj = new MatchesObject(userId, name, profileImageUrl, lastMessage,unseenMessages,chatKey);
//                        resultsMatches.add(obj);
//                        mMatchesAdapter.notifyDataSetChanged();
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }


    private void FetchMatchInformation(String key) {
        //DatabaseReference userDb = FirebaseDatabase.getInstance().getReference().child("Chat").child(chatKey).child("messages");
        DatabaseReference userDb = FirebaseDatabase.getInstance().getReference();
        userDb.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                unseenMessages = 0;
                lastSeenMessage = "";
                chatKey = snapshot.child("Users").child(currentUserID).child("connections").child("matches").child(key).child("chatId").getValue(String.class);;
                lastSeenMessage = snapshot.child("Users").child(currentUserID).child("connections").child("matches").child(key).child("last_msg").getValue(String.class);

                String userId = key;
                String name = "";
                String profileImageUrl = "";

                if (snapshot.child("Users").child(key).child("name").getValue() != null) {
                    name = snapshot.child("Users").child(key).child("name").getValue().toString();
                }
                if (snapshot.child("Users").child(key).child("profileImageUrl").getValue() != null) {
                    profileImageUrl = snapshot.child("Users").child(key).child("profileImageUrl").getValue().toString();
                }

                for (DataSnapshot dataSnapshot : snapshot.child("Chat").child(chatKey).child("messages").getChildren()) {
                    if (lastSeenMessage != null) {
                        long getMessageKey = Long.parseLong(dataSnapshot.getKey());
                        long getLastSeenMessage = Long.parseLong(lastSeenMessage);
                        lastMessage = dataSnapshot.child("msg").getValue(String.class);
                        if (getMessageKey > getLastSeenMessage) {
                            unseenMessages++;
                        }
                    }
                }
                if (lastSeenMessage == null) {
                    lastMessage = "";
                    unseenMessages = 0;
                }
                dataSet = true;
                MatchesObject obj = new MatchesObject(userId, name, profileImageUrl, lastMessage,unseenMessages,chatKey);
                resultsMatches.add(obj);
                mMatchesAdapter.notifyDataSetChanged();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) { }
        });
    }



    private void FetchMatchInformation1(String key) {
        DatabaseReference userDb = FirebaseDatabase.getInstance().getReference();
        userDb.child("Users").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String userId = key;
                    String name = "";
                    String profileImageUrl = "";

                    if (snapshot.child("name").getValue() != null) {
                        name = snapshot.child("name").getValue().toString();
                    }
                    if (snapshot.child("profileImageUrl").getValue() != null) {
                        profileImageUrl = snapshot.child("profileImageUrl").getValue().toString();
                    }
                    //if (!dataSet) {
                        dataSet = true;
                        MatchesObject obj = new MatchesObject(userId, name, profileImageUrl, lastMessage,unseenMessages,chatKey);
                        resultsMatches.add(obj);
                        mMatchesAdapter.notifyDataSetChanged();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

//    private void getLastMsgTS() {
//        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference().child("Chat").child(chatKey);
//        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    lastSeenMessage = snapshot.child("last_msg").getValue(String.class);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }


    private ArrayList<MatchesObject> resultsMatches = new ArrayList<MatchesObject>();
    private List<MatchesObject> getDataSetMatches() {
        return resultsMatches;
    }

}
