package com.example.socialme.Chat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.socialme.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;

//public class ChatActivity extends AppCompatActivity {
//    private RecyclerView mRecyclerView;
//    private RecyclerView.Adapter mChatAdapter;
//    private RecyclerView.LayoutManager mChatLayoutManager;
//
//    private EditText mSendEditText;
//
//    private Button mSendButton;
//
//    private String currentUserID, matchId, chatId;
//
//    DatabaseReference mDatabaseUser, mDatabaseChat;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_chat);
//
//        matchId = getIntent().getExtras().getString("matchId");
//
//        currentUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
//
//        mDatabaseUser = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID).child("connections").child("matches").child(matchId).child("chatId");
//        mDatabaseChat = FirebaseDatabase.getInstance().getReference().child("Chat");
//
//        getChatId();
//
//        mRecyclerView = findViewById(R.id.recyclerView);
//        mRecyclerView.setNestedScrollingEnabled(false);
//        mRecyclerView.setHasFixedSize(false);
//        mChatLayoutManager = new LinearLayoutManager(ChatActivity.this);
//        mRecyclerView.setLayoutManager(mChatLayoutManager);
//        mChatAdapter = new ChatAdapter(getDataSetChat(), ChatActivity.this);
//        mRecyclerView.setAdapter(mChatAdapter);
//
//        mSendEditText = findViewById(R.id.message);
//        mSendButton = findViewById(R.id.send);
//
//        mSendButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                sendMessage();
//            }
//
//        });
//    }
//
//    private void sendMessage() {
//        String sendMessageText = mSendEditText.getText().toString();
//
//        if (!sendMessageText.isEmpty()) {
//            DatabaseReference newMessageDb = mDatabaseChat.push();
//
//            Map newMessage = new HashMap();
//            newMessage.put("createByUser", currentUserID);
//            newMessage.put("text", sendMessageText);
//
//            newMessageDb.setValue(newMessage);
//        }
//        mSendEditText.setText(null);
//    }
//
//    private void getChatId() {
//        mDatabaseUser.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    chatId = snapshot.getValue().toString();
//                    mDatabaseChat = mDatabaseChat.child(chatId);
//                    getChatMessages();
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }
//
//    private void getChatMessages() {
//        mDatabaseChat.addChildEventListener(new ChildEventListener() {
//            @Override
//            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//                if (snapshot.exists()) {
//                    String message = null;
//                    String createByUser = null;
//
//                    if (snapshot.child("text").getValue() != null) {
//                        message = snapshot.child("text").getValue().toString();
//                    }
//                    if (snapshot.child("createByUser").getValue() != null) {
//                        createByUser = snapshot.child("createByUser").getValue().toString();
//                    }
//
//                    if (message != null && createByUser != null) {
//                        Boolean currentUserBoolean = false;
//                        if (createByUser.equals(currentUserID)) {
//                            currentUserBoolean = true;
//                        }
//                        ChatObject newMessage = new ChatObject(message, currentUserBoolean);
//                        resultsChat.add(newMessage);
//                        mChatAdapter.notifyDataSetChanged();
//                    }
//                }
//            }
//
//            @Override
//            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//            }
//            @Override
//            public void onChildRemoved(@NonNull DataSnapshot snapshot) {
//            }
//            @Override
//            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
//            }
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//            }
//        });
//    }
//
//
//    private ArrayList<ChatObject> resultsChat = new ArrayList<ChatObject>();
//    private List<ChatObject> getDataSetChat() {
//        return resultsChat;
//    }
//}

public class ChatActivity extends AppCompatActivity {
    private final List<ChatObject> chatLists = new ArrayList<>();
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference();
    private String chatId;
    // String = "";
    private RecyclerView chatRecyclerView;
    private ChatAdapter chatAdapter;
    private boolean loadingFirstTime = true;
    private String LastMsg = "0";
    // private String , matchId, chatId;

    DatabaseReference mDatabaseUser, mDatabaseChat;
    private String userId = "";
    private String currentUserId = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        userId = getIntent().getStringExtra("userId");
        currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        // matchId = getIntent().getExtras().getString("userId");  // FIXME LATER

        //currentUserID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        // mDatabaseUser = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserID).child("connections").child("matches").child(matchId).child("chatId");
       // mDatabaseChat = FirebaseDatabase.getInstance().getReference().child("Chat");

        final ImageView backBtn = findViewById(R.id.backBtn);
        final TextView name = findViewById(R.id.name);
        final EditText messageEditText = findViewById(R.id.messageEditTxt);
        final CircleImageView profilePic = findViewById(R.id.profilePic);
        final ImageView sendBtn = findViewById(R.id.sendBtn);
        chatRecyclerView = findViewById(R.id.chatRecyclerView);

        final String getName = getIntent().getStringExtra("name");
        final String getProfilePic = getIntent().getStringExtra("profile_pic");
       // chatId = getIntent().getStringExtra("chat_key");
//        private String userId = getIntent().getStringExtra("userId");
//        private String currentUserId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        //final String chatId = "";
        
        mDatabaseUser = FirebaseDatabase.getInstance().getReference().child("Users").child(currentUserId).child("connections").child("matches").child(userId).child("chatId");
        // getUserId = MemoryData.getData(ChatActivity.this);  // FIXME LATER

        name.setText(getName);
        if (!getProfilePic.isEmpty() && !getProfilePic.equals("default")) {
            Picasso.get().load(getProfilePic).into(profilePic);
        }

        chatRecyclerView.setHasFixedSize(true);
        chatRecyclerView.setLayoutManager(new LinearLayoutManager(ChatActivity.this));

        chatAdapter = new ChatAdapter(chatLists, ChatActivity.this);
        chatRecyclerView.setAdapter(chatAdapter);
        
        getChatId();
        // if (chatId.equals("")) chatId = FirebaseDatabase.getInstance().getReference().child("Chat").push().getKey();
        
        
//        if (chatId.isEmpty()) {
//            databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
//                @Override
//                public void onDataChange(@NonNull DataSnapshot snapshot) {
//                    chatId = "1";
//                    if(snapshot.hasChild("Chat")) {
//                        chatId = String.valueOf(snapshot.child("Chat").getChildrenCount() + 1);
//                    }
//                }
//
//                @Override
//                public void onCancelled(@NonNull DatabaseError error) {
//
//                }
//            });
//        }


        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChild("Chat")) {
                    if (snapshot.child("Chat").child(chatId).hasChild("messages")) {
                        chatLists.clear();
                        for (DataSnapshot messagesSnapshot : snapshot.child("Chat").child(chatId).child("messages").getChildren()){
                            if (messagesSnapshot.hasChild("msg") && messagesSnapshot.hasChild("createByUser")) {
                                final String messageTimestamps = messagesSnapshot.getKey();
                                final String getUserId = messagesSnapshot.child("createByUser").getValue(String.class);
                                final String getMsg = messagesSnapshot.child("msg").getValue(String.class);

                                Timestamp timestamp = new Timestamp(Long.parseLong(messageTimestamps));
                                Date date = new Date(timestamp.getTime());
                                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                                SimpleDateFormat simpleTimeFormat = new SimpleDateFormat("hh:mm aa", Locale.getDefault());
                                Boolean currentUser = false;
                                if (messagesSnapshot.child("createByUser").getValue().equals(currentUserId)) currentUser = true;
                                ChatObject chatList = new ChatObject(currentUser, getName, getMsg, simpleDateFormat.format(date), simpleTimeFormat.format(date));
                                chatLists.add(chatList);

                                getLastMsgTS();
                                if (loadingFirstTime || Long.parseLong(messageTimestamps) > Long.parseLong(LastMsg)) {
                                    loadingFirstTime = false;

                                    databaseReference.child("Users").child(currentUserId).child("connections").child("matches").child(userId).child("last_msg").setValue(messageTimestamps);
                                    chatAdapter.updateChatList(chatLists);

                                    chatRecyclerView.scrollToPosition(chatLists.size() - 1);

                                }
                            }

                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String getTxtMessage = messageEditText.getText().toString();
                final String currentTimestamp = String.valueOf(System.currentTimeMillis()).substring(0, 10);

                if (!getTxtMessage.isEmpty()) {
                    databaseReference.child("Users").child(currentUserId).child("connections").child("matches").child(userId).child("last_msg").setValue(currentTimestamp);
                    databaseReference.child("Chat").child(chatId).child("user_1").setValue(currentUserId);
                    databaseReference.child("Chat").child(chatId).child("user_2").setValue(userId);
                    databaseReference.child("Chat").child(chatId).child("messages").child(currentTimestamp).child("msg").setValue(getTxtMessage);
                    databaseReference.child("Chat").child(chatId).child("messages").child(currentTimestamp).child("createByUser").setValue(currentUserId);
                }
                messageEditText.setText("");
            }
        });
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void getChatId() {
        mDatabaseUser.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    chatId = snapshot.getValue().toString();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

//    private void getLastMsgTS() {
//        databaseReference.child("Chat").child(chatId).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    LastMsg = snapshot.child("last_msg").getValue(String.class);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }

    private void getLastMsgTS() {
        databaseReference.child("Users").child(currentUserId).child("connections").child("matches").child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    LastMsg = snapshot.child("last_msg").getValue(String.class);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}



