package com.example.socialme;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.io.IOError;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class EditProfile extends AppCompatActivity {

    private ImageView add1, add2, add3, add4, add5, add6, add7, add8, add9;


    private ImageView image1, image2, image3, image4, image5, image6, image7, image8, image9;
    



//    private ImageView add[] = new ImageView[9];
//    private ImageView profileImages[] = new ImageView[9];
//    private int addButtonIds[] = {R.id.add1, R.id.add2, R.id.add3};
//    private int profileImageIds[] = {};



    private TextView saveButton;

    public Uri imageUri;
    private FirebaseStorage storage;
    private StorageReference storageReference;


    private DatabaseReference databaseReference;
    private FirebaseAuth mAuth;
    private String userId;
    private String petBreed;
    private EditText nameField, ageField, cityField, genderField, breedField;

    private String myUri = "";
    private StorageTask uploadTask;
    private StorageReference storageProfilePicsRef;

    private Uri resultUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_edit);

        add1 = findViewById(R.id.add1);
        add2 = findViewById(R.id.add2);
        add3 = findViewById(R.id.add3);
        add4 = findViewById(R.id.add4);
        add5 = findViewById(R.id.add5);
        add6 = findViewById(R.id.add6);
        add7 = findViewById(R.id.add7);
        add8 = findViewById(R.id.add8);
        add9 = findViewById(R.id.add9);


        image1 = findViewById(R.id.image1);
        image2 = findViewById(R.id.image2);
        image3 = findViewById(R.id.image3);
        image4 = findViewById(R.id.image4);
        image5 = findViewById(R.id.image5);
        image6 = findViewById(R.id.image6);
        image7 = findViewById(R.id.image7);
        image8 = findViewById(R.id.image8);
        image9 = findViewById(R.id.image9);

        // new
//        for (int index = 0; index < 9; index++) {
//            add[index] = findViewById(addButtonIds[index]);
//            profileImageIds[index] = findViewById(profileImageIds[index]);
//        }



        saveButton = findViewById(R.id.save_button);

        nameField = findViewById(R.id.pet_name);
        ageField = findViewById(R.id.pet_age);
        cityField = findViewById(R.id.city);
        genderField = findViewById(R.id.city);
        breedField = findViewById(R.id.pet_breed);

        // add new
        petBreed = getIntent().getExtras().getString("petBreed");
        mAuth = FirebaseAuth.getInstance();
        userId = mAuth.getCurrentUser().getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(userId);
        storageProfilePicsRef = FirebaseStorage.getInstance().getReference().child("images");


        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        //       getUserinfo();

        add1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mGetContent.launch("image/*");
            }
        });



        // new

//        for (int index = 0; index < 9; index++) {
//            add[index].setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//
//                }
//            });
//        }



        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uploadImage();
            }
        });

    }


//    private void getUserinfo() {
//        databaseReference.child(mAuth.getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists() && snapshot.getChildrenCount() > 0)
//                {
//                    Map<String, Object> map = (Map<String, Object>) snapshot.getValue();
//                    if (map.get("name") != null) {
//
//                    }
//                   if (snapshot.hasChild("image"))
//                   {
//                       String image = snapshot.child("image").getValue().toString();
//                       Picasso.get().load(image).into(image1);
//
//                   }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });
//    }

    private void uploadImage() {
        ProgressDialog dialog = new ProgressDialog(this);
        dialog.setMessage("Uploading...");
        dialog.show();


//        if (imageUri != null) {
//            StorageReference reference = storage.getReference().child("images/" + UUID.randomUUID().toString());
//            reference.putFile(imageUri).addOnCompleteListener(new OnCompleteListener<UploadTask.TaskSnapshot>() {
//                @Override
//                public void onComplete(@NonNull Task<UploadTask.TaskSnapshot> task) {
//                    if (task.isSuccessful()) {
//                        dialog.dismiss();
//                        Toast.makeText(EditProfile.this, "Image Uploaded Successfully!", Toast.LENGTH_SHORT).show();
//
//                    } else {
//                        dialog.dismiss();
//                        Toast.makeText(EditProfile.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
//                    }
//                }
//            });
//        }


        if (imageUri != null) {
//            final StorageReference fileRef = storageProfilePicsRef.child(mAuth.getCurrentUser().getUid() + ".jpg");
            StorageReference fileRef = FirebaseStorage.getInstance().getReference().child("profileImages").child(userId);
            uploadTask = fileRef.putFile(imageUri);
            uploadTask.continueWithTask(new Continuation() {
                @Override
                public Object then(@NonNull Task task) throws Exception {
                    if (!task.isSuccessful())
                    {
                        throw task.getException();
                    }

                    return fileRef.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull Task<Uri> task) {
                    if (task.isSuccessful())
                    {
                        Uri downloadUrl = task.getResult();
                        myUri = downloadUrl.toString();

                        HashMap<String, Object> userMap = new HashMap<>();
                        userMap.put("image", myUri);

//                        databaseReference.child(mAuth.getCurrentUser().getUid()).updateChildren(userMap);
                        databaseReference.updateChildren(userMap);
                        dialog.dismiss();

                    }

                }
            });
        }
        else {
            dialog.dismiss();
            Toast.makeText(this, "Error, try Again", Toast.LENGTH_SHORT).show();
        }
    }


    ActivityResultLauncher<String> mGetContent = registerForActivityResult(new ActivityResultContracts.GetContent(),
            new ActivityResultCallback<Uri>() {
                @Override
                public void onActivityResult(Uri result) {
                    if (result != null) {
                        image1.setImageURI(result);
                        imageUri = result;
                    }
                }
            });

}