package com.example.socialme.Matches;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.socialme.Chat.ChatActivity;
import com.example.socialme.R;
import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

//public class MatchesAdapter extends RecyclerView.Adapter<MatchesViewHolders> {
//    private List<MatchesObject> matchesList;
//    private Context context;
//
//
//    public MatchesAdapter(List<MatchesObject> matchesList, Context context) {
//        this.matchesList = matchesList;
//        this.context = context;
//
//    }
//    @NonNull
//    @Override
//    public MatchesViewHolders onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_matches, null, false);
//        RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
//        layoutView.setLayoutParams(lp);
//        MatchesViewHolders rcv = new MatchesViewHolders((layoutView));
//
//        return rcv;
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull MatchesViewHolders holder, int position) {
//        holder.mMatchId.setText(matchesList.get(position).getUserId());
//        holder.mMatchName.setText(matchesList.get(position).getName());
//        if (!matchesList.get(position).getProfileImageUrl().equals("default")) {
//            Glide.with(context).load(matchesList.get(position).getProfileImageUrl()).into(holder.mMatchImage);
//        }
//
//    }
//
//    @Override
//    public int getItemCount() {
//        return matchesList.size();
//    }
//}


public class MatchesAdapter extends RecyclerView.Adapter<MatchesAdapter.MyViewHolder> {

    public MatchesAdapter(List<MatchesObject> matchLists, Context context) {
        this.matchLists = matchLists;
        this.context = context;
    }

    private final List<MatchesObject> matchLists;
    private final Context context;
    @NonNull
    @Override
    public MatchesAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_matches, null));
    }

    @Override
    public void onBindViewHolder(@NonNull MatchesAdapter.MyViewHolder holder, int position) {
        MatchesObject obj = matchLists.get(position);

        if(!obj.getProfileImageUrl().isEmpty() && !obj.getProfileImageUrl().equals("default")) {
            Picasso.get().load(obj.getProfileImageUrl()).into(holder.mMatchImage);
        }


        holder.mMatchName.setText(obj.getName());
        holder.lastMessage.setText(obj.getLastMessage());

        if(obj.getUnseenMessages() == 0) {
            holder.unseenMessages.setVisibility(View.GONE);
            holder.lastMessage.setTextColor(Color.parseColor("#959595"));
        } else {
            holder.unseenMessages.setVisibility(View.VISIBLE);
            holder.unseenMessages.setText(obj.getUnseenMessages()+"");
            holder.lastMessage.setTextColor(context.getResources().getColor(R.color.chat_color_80));
        }

        holder.rootLayout.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, ChatActivity.class);
                intent.putExtra("userId", obj.getUserId());
                intent.putExtra("name", obj.getName());
                intent.putExtra("profile_pic", obj.getProfileImageUrl());
                intent.putExtra("chat_key", obj.getChatKey());

                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return matchLists.size();
    }


    static class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView mMatchName, lastMessage;
        private CircleImageView mMatchImage;
        private TextView unseenMessages;
        private LinearLayout rootLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            mMatchName = itemView.findViewById(R.id.name);
            mMatchImage = itemView.findViewById(R.id.MatchImage);
            lastMessage = itemView.findViewById(R.id.lastMessage);
            unseenMessages = itemView.findViewById(R.id.unseenMessages);
            rootLayout = itemView.findViewById(R.id.rootLayout);
        }
    }
}
