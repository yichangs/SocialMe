package com.example.socialme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class RegistrationActivity extends AppCompatActivity {
    private ImageView goBack;
    private EditText username;
    private EditText email;
    private EditText password;
    private RadioGroup mRadioGroup;
    private Button signUpButton;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener firebaseAuthStateListener;

    private void switchActivity() {
        Intent switchActivityIntent = new Intent(this, MainActivity.class);
        startActivity(switchActivityIntent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        mAuth = FirebaseAuth.getInstance();
//        firebaseAuthStateListener = (firebaseAuth) -> {
//            final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//            if (user != null) {
//                Intent intent = new Intent(RegistrationActivity.this, AccountActivity.class);
//                startActivity(intent);
//                Toast.makeText(RegistrationActivity.this, "Record is inserted", Toast.LENGTH_SHORT).show();
//                finish();
//                return;
//            }
//        };


//        firebaseAuthStateListener = new FirebaseAuth.AuthStateListener() {
//            @Override
//            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
//                final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
//                if (user != null) {
//                    Intent intent = new Intent(RegistrationActivity.this, MainActivity.class);
//                    startActivity(intent);
//                    finish();
//                    return;
//                }
//            }
//        };


        goBack = findViewById(R.id.goBack);
        username = findViewById(R.id.username);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        mRadioGroup = findViewById(R.id.radios);
        signUpButton = findViewById(R.id.signUpButton);


        goBack.setOnClickListener((View v) -> {
            switchActivity();
        });

        signUpButton.setOnClickListener((View v) -> {
            int selectId = mRadioGroup.getCheckedRadioButtonId();

            final RadioButton radioButton = findViewById(selectId);

            if (radioButton.getText() == null) {
                return;
            }

            String editName = username.getText().toString().trim();
            String editEmail = email.getText().toString().trim();
            String editPassword = password.getText().toString();

            if (editName.isEmpty()) {
                username.setError("User name is required!");
                username.requestFocus();
                return;
            }


            if (editEmail.isEmpty()) {
                email.setError("Email is required!");
                email.requestFocus();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(editEmail).matches()) {
                email.setError("Please provide valid email!");
                email.requestFocus();
                return;
            }


            if (editPassword.isEmpty()) {
                password.setError("Password is required!");
                password.requestFocus();
                return;
            }

            if (editPassword.length() < 6) {
                password.setError("Min password length should be 6 characters!");
                password.requestFocus();
                return;
            }

            mAuth.createUserWithEmailAndPassword(editEmail, editPassword).addOnCompleteListener(RegistrationActivity.this, (task) -> {
                if (!task.isSuccessful()) {
                    Toast.makeText(RegistrationActivity.this, "sign up error", Toast.LENGTH_SHORT).show();
                } else {
                    String userId = mAuth.getCurrentUser().getUid();
                    DatabaseReference currentUserDb = FirebaseDatabase.getInstance().getReference().child("Users").child(userId);
                    Map userInfo = new HashMap<>();
                    userInfo.put("name", editName);
                    userInfo.put("breed", radioButton.getText().toString());
                    userInfo.put("profileImageUrl", "default");

                    currentUserDb.updateChildren(userInfo);
                    Intent intent = new Intent(RegistrationActivity.this, AccountActivity.class);
                   // intent.putExtra("name", editName);
                    startActivity(intent);
                }
            });


//    @Override
//    protected void onStart() {
//        super.onStart();
//        mAuth.addAuthStateListener(firebaseAuthStateListener);
//    }

//    @Override
//    protected void onStop() {
//        super.onStop();
//        mAuth.removeAuthStateListener(firebaseAuthStateListener);
//    }
//
        });
    }
}